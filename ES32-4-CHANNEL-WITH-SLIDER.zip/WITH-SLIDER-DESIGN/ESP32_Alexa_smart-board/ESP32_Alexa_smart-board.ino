// #include <ESP8266WiFi.h>
#include <WiFi.h>
#include <WebServer.h>
#include <fauxmoESP.h>
#include "index.h"
#include <WiFiManager.h>
#include <Update.h>

WiFiManager wm;
fauxmoESP fauxmo;
WebServer server(81);

#define WEB_USERNAME "admin"
#define WEB_PASSWORD "Admin@123"

#define RELAY_PIN1     25
#define RELAY_PIN2     26
#define RELAY_PIN3     27
#define RELAY_PIN4     32
//Fan pins
#define RELAY_PIN5     33
#define RELAY_PIN6     18
#define RELAY_PIN7     19
// Active LOW relay
#define RELAY_ON       LOW
#define RELAY_OFF      HIGH
// WiFi connection timeout (milliseconds)
#define WIFI_TIMEOUT   20000
constexpr uint8_t RELAY_COUNT = 7;
const uint8_t relayPins[RELAY_COUNT] = {
    RELAY_PIN1, RELAY_PIN2, RELAY_PIN3, RELAY_PIN4, RELAY_PIN5, RELAY_PIN6, RELAY_PIN7
};
bool wifiConfigured = false;
bool relayState[RELAY_COUNT] = {false};
unsigned long relayLastChange[RELAY_COUNT] = {0};
constexpr uint32_t MIN_SWITCH_INTERVAL = 1000;
unsigned long lastRequest = 0;

bool validateRequest(){ return allowRequest(); }

void restartESP() {
    if(!validateRequest()) return;
    server.send(200,"text/plain","Restarting");
    server.client().stop();
    delay(200);
    ESP.restart();
}

void getInfo() {
    if(!validateRequest()) return;
    String json = "{\"url\":\"http://" + WiFi.localIP().toString() + "\",\"relayCount\":" + String(RELAY_COUNT) + "}";
    server.send(200, "application/json", json);
}

bool allowRequest() {
    if (millis() - lastRequest < 200) {
        server.send(429,"text/plain","Too Many Requests");
        return false;
    }
    lastRequest = millis();
    return true;
}

void handleRoot() { server.send_P(200,"text/html",INDEX_HTML); }

// void setRelay(uint8_t relay, bool on) {
//     Serial.println(relay);
//     if (relay >= RELAY_COUNT) return;
//     if (relayState[relay] == on) return;
    
//     unsigned long now = millis();
//     if (now - relayLastChange[relay] < MIN_SWITCH_INTERVAL) return;

//     relayState[relay] = on;
//     relayLastChange[relay] = now;
//     digitalWrite(relayPins[relay], on ? RELAY_ON : RELAY_OFF);
// }
void setRelay(uint8_t relay, bool on) {
    Serial.println(relay);
    if (relay >= RELAY_COUNT) return;
    // if (relayState[relay] == on) return;
    
    unsigned long now = millis();
    if (now - relayLastChange[relay] < MIN_SWITCH_INTERVAL) return;

    if(relay == 1 || relay == 2 || relay == 3){
        if(relay == 1) {
            digitalWrite(relayPins[relay], RELAY_ON);
            digitalWrite(relayPins[2], RELAY_OFF);
            digitalWrite(relayPins[3], RELAY_OFF);
        }
        if(relay == 2) {
            digitalWrite(relayPins[relay], RELAY_ON);
            digitalWrite(relayPins[1], RELAY_OFF);
            digitalWrite(relayPins[3], RELAY_OFF);
        }
        if(relay == 3) {
            digitalWrite(relayPins[relay], RELAY_ON);
            digitalWrite(relayPins[1], RELAY_OFF);
            digitalWrite(relayPins[2], RELAY_OFF);
        }
    } else {
        // relayState[relay] = on;
        // relayLastChange[relay] = now;
        // digitalWrite(relayPins[relay], on ? RELAY_ON : RELAY_OFF);
        setOnOffRelay(relay, on);
    }
}
void setOnOffRelay(uint8_t relay, bool on) {
    Serial.println(relay);
    if (relay >= RELAY_COUNT) return;
    if (relayState[relay] == on) return;
    
    unsigned long now = millis();
    if (now - relayLastChange[relay] < MIN_SWITCH_INTERVAL) return;

    relayState[relay] = on;
    relayLastChange[relay] = now;
    digitalWrite(relayPins[relay], on ? RELAY_ON : RELAY_OFF);
}

// void setFanRelay(uint8_t relay, bool on) {
//     Serial.println(relay);
//     Serial.println(on);
//     if (relay >= RELAY_COUNT) return;
//     // if (relayState[relay] == on) return;
    
//     unsigned long now = millis();
//     if (now - relayLastChange[relay] < MIN_SWITCH_INTERVAL) return;

//     switch (relay) {
//         case 4:
//             Serial.println(RELAY_PIN4);
//             digitalWrite(relayPins[relay], RELAY_ON);
//             digitalWrite(relayPins[RELAY_PIN5], RELAY_OFF);
//             digitalWrite(relayPins[RELAY_PIN6], RELAY_OFF);
//             break;

//         case 5:
//             Serial.println(RELAY_PIN6);
//             digitalWrite(relayPins[relay], RELAY_ON);
//             digitalWrite(relayPins[RELAY_PIN6], RELAY_OFF);
//             digitalWrite(relayPins[RELAY_PIN7], RELAY_OFF);
//             break;

//         case 6:
//             Serial.println(RELAY_PIN7);
//             digitalWrite(relayPins[relay], RELAY_ON);
//             digitalWrite(relayPins[RELAY_PIN5], RELAY_OFF);
//             digitalWrite(relayPins[RELAY_PIN6], RELAY_OFF);
//             break;

//         default:
//             Serial.println("Invalid relay");
//     }
// }

void relayHandler()
{
   if(!validateRequest()) return;
    String uri = server.uri();
    uint8_t relay = uri.charAt(2) - '1';
    bool on = uri.endsWith("/on");
    setRelay(relay, on);
    server.send(204);
}
// void fanRelayHandler()
// {
//    if(!validateRequest()) return;
//     String uri = server.uri();
//     uint8_t relay = uri.charAt(2) - '1';
//     bool on = uri.endsWith("/on");
//     setFanRelay(relay, on);
//     server.send(204);
// }

void setup() {
    Serial.begin(115200);
    for (uint8_t i = 0; i < RELAY_COUNT; i++) {
        pinMode(relayPins[i], OUTPUT);
        digitalWrite(relayPins[i], RELAY_OFF);
    }
    WiFi.persistent(true);
    WiFi.setAutoReconnect(true);
    WiFi.setSleep(false);
    // startESWebAP();
    wm.setHostname("smart-relay");
    wm.setConnectTimeout(10);
    wm.setConfigPortalTimeout(180);
    wm.setBreakAfterConfig(false);
    // Connect to saved router / open setup portal if needed
    if (wm.autoConnect("FTS_D1_Setup", "Connect@12")) {
        wifiConfigured = true;
    } else {
        wifiConfigured = false;
    }
    // Restore permanent AP after WiFiManager
    startESWebAP();
    // ---------- Alexa / fauxmoESP ----------
    fauxmo.createServer(true);
    fauxmo.setPort(80);
    fauxmo.enable(true);
    fauxmo.addDevice("Switch1");
    fauxmo.addDevice("Switch2");
    fauxmo.addDevice("Switch3");
    fauxmo.addDevice("Switch4");
    fauxmo.onSetState([](unsigned char id, const char *name, bool state, unsigned char value) {
        if (!strcmp(name, "Switch1")) setRelay(0, !state);
        else if (!strcmp(name, "Switch2")) setRelay(1, !state);
        else if (!strcmp(name, "Switch3")) setRelay(2, !state);
        else if (!strcmp(name, "Switch4")) setRelay(3, !state);
    });
    // ---------- Web Server ----------
    server.on("/", handleRoot);
    server.on("/r1/on", HTTP_POST, relayHandler);
    server.on("/r1/off", HTTP_POST, relayHandler);
    server.on("/r2/on", HTTP_POST, relayHandler);
    server.on("/r2/off", HTTP_POST, relayHandler);
    server.on("/r3/on", HTTP_POST, relayHandler);
    server.on("/r3/off", HTTP_POST, relayHandler);
    server.on("/r4/on", HTTP_POST, relayHandler);
    server.on("/r4/off", HTTP_POST, relayHandler);
    
    server.on("/r5/on", HTTP_POST, relayHandler);
    server.on("/r5/off", HTTP_POST, relayHandler);    
    server.on("/r6/on", HTTP_POST, relayHandler);
    server.on("/r6/off", HTTP_POST, relayHandler);    
    server.on("/r7/on", HTTP_POST, relayHandler);
    server.on("/r7/off", HTTP_POST, relayHandler);

    server.on("/status", HTTP_POST, getInfo);
    server.on("/restart", HTTP_POST, restartESP);

    server.on("/update", HTTP_GET, handleUpdatePage);
    server.on("/update", HTTP_POST,
        []() {
            if (!server.authenticate(WEB_USERNAME, WEB_PASSWORD)) {
                return server.requestAuthentication();
            }
            server.sendHeader("Connection", "close");
            server.send(200, "text/plain",
                        Update.hasError() ? "Update failed" : "Update successful. Restarting...");
            
            delay(1000);
            ESP.restart();
        },
        handleFirmwareUpload
    );

    server.begin();
}

void startESWebAP() {
    IPAddress apIP(192,168,5,1);
    IPAddress apGW(192,168,5,1);
    IPAddress apMask(255,255,255,0);

    WiFi.mode(WIFI_AP_STA);
    delay(100);
    bool cfg = WiFi.softAPConfig(apIP, apGW, apMask);
    bool apOK = WiFi.softAP("FTS_D1_Device", "Connect@12");
}

void handleUpdatePage() {
    if (!server.authenticate(WEB_USERNAME, WEB_PASSWORD)) {
        return server.requestAuthentication();
    }
    server.send(200, "text/html",
        "<html><body><h2>Smart Relay Firmware Update</h2>"
        "<form method='POST' action='/update' enctype='multipart/form-data'>"
        "<input type='file' name='firmware' accept='.bin' required>"
        "<br><br><input type='submit' value='Update Firmware'>"
        "</form></body></html>"
    );
}

void handleFirmwareUpload() {
    HTTPUpload& upload = server.upload();
    if (upload.status == UPLOAD_FILE_START) {
        Serial.printf("Updating: %s\n", upload.filename.c_str());

        // if (!Update.begin(upload.contentLength)) {
        if (!Update.begin(UPDATE_SIZE_UNKNOWN)) {
            Update.printError(Serial);
        }
    } 
    else if (upload.status == UPLOAD_FILE_WRITE) {
        if (Update.write(upload.buf, upload.currentSize) != upload.currentSize) {
            Update.printError(Serial);
        }
    } 
    else if (upload.status == UPLOAD_FILE_END) {
        if (Update.end(true)) {
            Serial.printf("Update successful: %u bytes\n", upload.totalSize);
        } else {
            Update.printError(Serial);
        }
    }
}

void loop() {
    fauxmo.handle();
    server.handleClient();
    if(wifiConfigured) {
        static uint32_t lastWiFiCheck = 0;
        if (millis() - lastWiFiCheck >= 5000) {
            lastWiFiCheck = millis();
            if (WiFi.status() != WL_CONNECTED) {
                WiFi.reconnect();
            }
        }
    }
    yield();
}