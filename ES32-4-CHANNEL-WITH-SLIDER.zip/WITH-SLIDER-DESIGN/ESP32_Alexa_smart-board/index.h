#ifndef WEBPAGE_H
#define WEBPAGE_H

const char INDEX_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Smart Home</title>
        <style>
            *{margin:0;padding:0;box-sizing:border-box;font-family:Arial}
            body{min-height:100%;display:flex;align-items:center;justify-content:center;background:#f2f4f8;padding:50px}
            .box{position:relative;width:320px;max-width:100%;padding:20px;background:#fff;border-radius:12px;box-shadow:0 4px 12px #0002}
            h2{text-align:center;margin:0 0 20px}
            .row{display:flex;align-items:center;justify-content:space-between;margin:15px 0}
            .buttons{display:flex;gap:8px}
            button{border:0;padding:8px 15px;border-radius:20px;color:#fff;font-weight:bold}
            .on{background:#28a745}
            .off{background:#dc3545}
            .restart{position:absolute;top:12px;right:12px;padding:6px 12px;background:#ff9800;font-size:12px}
            button.active {transform: scale(0.95);font-weight: bold;box-shadow: 0 0 0 2px #fff, 0 0 8px #555;}
            .card{background:white;padding:28px;border-radius:22px;width:280px;text-align:center;box-shadow:0 8px 30px #ccd5e555}
           input{width:100%;accent-color:#1677ff;cursor:pointer}
        </style>
    </head>
    <body>
        <div class="box">
            <button class="restart" onclick="restartESP()">Restart</button>
            <h2>Smart Home</h2>
            <div id="switches"></div>
            <div class="card">
                <h2>Fan Control</h2>
                <div id="speed">2</div>
                <input id="fan" type="range" min="1" max="3" value="2" step="1">
                <div class="row"><span>Low</span><span>Medium</span><span>High</span></div>
            </div>
        </div>
    </body>
    <script>
        let locked = false;
        const relay = (i, s, btn) => {
            if (locked) return; locked = true;
            const allButtons = document.querySelectorAll(".buttons button"); 
            allButtons.forEach(b => b.disabled = true);

            fetch(`/r${i}/${s}`, {method:"POST"}) 
                .then(() => {
                    setTimeout(() => { const buttons = btn.parentElement.querySelectorAll("button");
                        if(buttons) {
                            buttons.forEach(b => b.classList.remove("active"));
                            btn.classList.add("active"); 
                        }
                    }, 200);
            })
            .finally(() => {
                setTimeout(() => { allButtons.forEach(b => b.disabled = false);
                    locked = false; }, 200);
            });
        }
        function restartESP() {
            if (!confirm("Want to Restart Smart Board?")) return;
            fetch("/restart", {method: "POST"})
                .then(() => {alert("Restart command sent.");})
                .catch(() => {alert("Unable to restart.");});
        }
        let h='';
        for(let i=5;i<=6;i++) {
            h+=`<div class="row"><span>Light</span><div class="buttons">
            <button class="on" onclick="relay(${i},'off',this)">ON</button>
            <button class="off" onclick="relay(${i},'on',this)">OFF</button>
            </div></div>`;
        }
        h+=`<div class="row"><span>FAN</span><div class="buttons">
            <button class="on" onclick="relay(1,'off',this)">ON</button>
            <button class="off" onclick="relay(1,'on',this)">OFF</button>
            </div></div>`;
        document.getElementById('switches').innerHTML=h;
        
        fan.oninput=()=>{speed.textContent=fan.value;};
        fan.onchange=()=>{
            speed.textContent=fan.value;
            const val = (fan.value && fan.value == "1") ? 2 : ((fan.value && fan.value == "2") ? 3 : ((fan.value && fan.value == "3") ? 4 : null));
            if(val) {relay(val,'off',this); }
        }
    </script>
</html>
)rawliteral";

#endif